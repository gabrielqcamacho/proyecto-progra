document.addEventListener("DOMContentLoaded", function () {
  const combo = document.getElementById("playas");
  const imagen = document.getElementById("imagenDemo");
  const descripcion = document.getElementById("descripcion");

  combo.addEventListener("change", function () {
    const opcion = combo.value;
    let url = "https://via.placeholder.com/300x200?text=Selecciona+una+opción";
    let texto = "";

    switch (opcion) {
      case "playaTamarindo":
        url = "img/img4.jpg";
        texto = "Playa Tamarindo es una playa de arena blanca, segura, pública y familiar, ideal para disfrutar del auténtico sentimiento de playa.";
        break;
      case "playaConchal":
        url = "img/img9.jpg";
        texto = "Playa Conchal está formada por millones de conchas trituradas en lugar de arena. Sus aguas turquesa son perfectas para nadar y hacer snorkel.";
        break;
      case "playaAvellanas":
        url = "img/img6.webp";
        texto = "Playa Avellanas es conocida por su ambiente tranquilo y condiciones excelentes para el surf, rodeada de naturaleza y manglares.";
        break;
      case "playaLasCatalinas":
        url = "img/img7.jpg";
        texto = "Las Catalinas se compone de dos playas hermosas: Danta y Dantita. Son ideales para nadar, hacer kayak y snorkel.";
        break;
      case "playaManuelAntonio":
        url = "img/img8.jpg";
        texto = "Playa Manuel Antonio destaca por sus aguas claras, arena blanca y exuberante vegetación tropical alrededor.";
        break;
    }

    imagen.style.opacity = 0;
    setTimeout(() => {
      imagen.src = url;
      descripcion.textContent = texto;
      imagen.style.opacity = 1;
    }, 300);
  });
});

function volverPrincipal() {
  window.location.href = "index.html";
}

