document.addEventListener("DOMContentLoaded", function() {
    const combo = document.getElementById("lugares");


    combo.addEventListener("change", function() {
        const url = combo.value;

        if (url) {
            mensaje.inneerHtML = `Redirigiendo a <b>${combo.options[combo.selectedIndex].text}</b>...`;


            setTimeout(() => {
                window.open(url, "_blank");
            }, 1000);
        }
    });
});

function volverPrincipal() {
  window.location.href = "index.html";
}
