document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("formRegistro");
  const combo = document.getElementById("comboUsuarios");
  const detalle = document.getElementById("detalleUsuario");

  const usuarios = [];

  function actualizarCombo() {
    combo.innerHTML = '<option value="">Seleccione un usuario</option>';
    usuarios.forEach((u, index) => {
      const option = document.createElement("option");
      option.value = index;
      option.textContent = u.nombre;
      combo.appendChild(option);
    });
  }

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const nombre = document.getElementById("nombre").value.trim();
    const cedula = document.getElementById("cedula").value.trim();
    const correo = document.getElementById("correo").value.trim();

    if(!nombre || !cedula || !correo) return;

    const nuevoUsuario = { nombre, cedula, correo };
    usuarios.push(nuevoUsuario);

    form.reset();
    actualizarCombo();
    alert("Usuario registrado con éxito!");
  });

  combo.addEventListener("change", () => {
    const index = combo.value;
    if(index === "") {
      detalle.innerHTML = "";
      return;
    }
    const u = usuarios[index];
    detalle.innerHTML = `
      <p><strong>Nombre:</strong> ${u.nombre}</p>
      <p><strong>Cédula:</strong> ${u.cedula}</p>
      <p><strong>Correo:</strong> ${u.correo}</p>
    `;
  });
});

function volverPrincipal() {
  window.location.href = "index.html"; 
}