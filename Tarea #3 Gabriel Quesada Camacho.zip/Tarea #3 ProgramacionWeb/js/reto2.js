document.getElementById("btnCalcular").addEventListener("click", calcularFactura);

function calcularFactura() {
  const cliente = document.getElementById("cliente").value;
  const articulo = document.getElementById("articulo").value;
  const cantidad = parseFloat(document.getElementById("cantidad").value);
  const precio = parseFloat(document.getElementById("precio").value);

  if (!cliente || !articulo || isNaN(cantidad) || isNaN(precio)) {
    alert("Complete los campos correctamente.");
    return;
  }

  const subtotal = cantidad * precio;
  const iva = subtotal * 0.13;
  const servicio = subtotal * 0.05;
  const total = subtotal + iva + servicio;

  const resultado = document.getElementById("resultado");
  resultado.innerHTML = `
    <p><strong>Nombre del cliente:</strong> ${cliente}</p>
    <p><strong>Artículo comprado:</strong> ${articulo}</p>
    <p><strong>Cantidad:</strong> ${cantidad}</p>
    <p><strong>Precio unitario:</strong> ₡${precio.toFixed(2)}</p>
    <p><strong>Subtotal:</strong> ₡${subtotal.toFixed(2)}</p>
    <p><strong>IVA (13%):</strong> ₡${iva.toFixed(2)}</p>
    <p><strong>Servicio (5%):</strong> ₡${servicio.toFixed(2)}</p>
    <p><strong>Total a pagar:</strong> <b>₡${total.toFixed(2)}</b></p>
  `;
}

document.getElementById("btnCancelar").addEventListener("click", () => { 
    swal.fire({
        title: "¿Desea cancelar la factura?",
        text: "Se borraran todos los datos ingresados.",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Si, Cancelar",
        cancelButtonText: "No, Volver"
    }).then((result) => {
        if (result.isConfirmed) {
            limpiarFormulario(); 

            swal.fire({
                title: "Factura cancelada",
                text: "Todos los datos se han limpiado correctamente.",
                icon: "succes",
                timer: 1800,
                showConfirmButton: false
            });
        }
    });
});

function volverPrincipal() {
  window.location.href = "index.html"; 
}


function limpiarFormulario() {
    document.getElementById("cliente").value = "";
    document.getElementById("articulo").value = "";
    document.getElementById("cantidad").value = "";
    document.getElementById("precio").value = "";

    const resultado = document.getElementById("resultado");
    resultado.innerHTML = `
    <p><strong>Nombre del cliente:</strong> - </p>
    <p><strong>Artículo comprado:</strong> - </p>
    <p><strong>Cantidad:</strong> - </p>
    <p><strong>Precio:</strong> - </p>
    <p><strong>Subtotal:</strong> - </p>
    <p><strong>IVA (13%):</strong> - </p>
    <p><strong>Servicio (5%):</strong> - </p>
    <p><strong>Total a pagar:</strong> - </p>
    `;
}