var empleados = [
    { cedula: "109110338", nombre: "Juan", apellidos: "Pérez", lugar: "San José", foto: "img/empleado5.jpg" },
    { cedula: "209110338", nombre: "María", apellidos: "Gómez", lugar: "Alajuela", foto: "img/empleado3.jpg" },
    { cedula: "309110338", nombre: "Carlos", apellidos: "Ramírez", lugar: "Heredia", foto: "img/empleado4.jpg" },
    { cedula: "409110338", nombre: "Ana", apellidos: "López", lugar: "Cartago", foto: "img/empleado2.jpg" },
    { cedula: "509110338", nombre: "Luis", apellidos: "Sánchez", lugar: "Guanacaste", foto: "img/empleado1.jpg" }
];

function buscarEmpleado() {
    var cedula = document.getElementById("cedulaInput").value.trim();
    var resultadoDiv = document.getElementById("resultadoDiv");

    resultadoDiv.classList.add("hidden");

    if (cedula === "") {
        Swal.fire("¡Atención!", "Por favor ingrese una cédula.", "warning");
        return;
    }

    var encontrado = false;
    for (var i = 0; i < empleados.length; i++) {
        if (empleados[i].cedula === cedula) {
            document.getElementById("nombre").textContent = empleados[i].nombre;
            document.getElementById("apellidos").textContent = empleados[i].apellidos;
            document.getElementById("lugar").textContent = empleados[i].lugar;
            document.getElementById("foto").src = empleados[i].foto;
            resultadoDiv.classList.remove("hidden");
            encontrado = true;
            break;
        }
    }

    if (!encontrado) {
        Swal.fire("Error", "El usuario NO existe", "error");
    }
}

function volverPrincipal() {
  window.location.href = "index.html";
}