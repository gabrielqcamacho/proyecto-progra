document.addEventListener("DOMContentLoaded", function() {
  const modelo = document.getElementById("modelo");
  const version = document.getElementById("version");
  const boton = document.getElementById("calcular");
  const mensaje = document.getElementById("mensaje");
  const imagen = document.getElementById("imagenIphone");

  modelo.addEventListener("change", function() {
    const seleccionado = modelo.value;
    version.innerHTML = '<option value="">Elige la versión</option>';

    if (seleccionado !== "") {
      const versiones = ["Normal", "Pro", "Pro Max"];
      versiones.forEach(v => {
        const opt = document.createElement("option");
        opt.value = v;
        opt.textContent = v;
        version.appendChild(opt);
      });
    }

    imagen.src = "https://via.placeholder.com/200x150?text=iPhone";
    mensaje.textContent = "";
  });

  boton.addEventListener("click", function() {
    const modeloSeleccionado = modelo.value;
    const versionSeleccionada = version.value;

    if (!modeloSeleccionado || !versionSeleccionada) {
      alert("Por favor selecciona modelo y versión.");
      return;
    }

    let precio = 0;
    let imgSrc = "";

    if (modeloSeleccionado === "iphone17") {
      if (versionSeleccionada === "Normal") { precio = 700; imgSrc = "img/iphone17.jpg"; }
      if (versionSeleccionada === "Pro") { precio = 850; imgSrc = "img/iphone17_pro.webp"; }
      if (versionSeleccionada === "Pro Max") { precio = 950; imgSrc = "img/iphone17_promax.webp"; }
    }

    if (modeloSeleccionado === "iphone16") {
      if (versionSeleccionada === "Normal") { precio = 800; imgSrc = "img/iphone16.webp"; }
      if (versionSeleccionada === "Pro") { precio = 950; imgSrc = "img/iphone16_pro.webp"; }
      if (versionSeleccionada === "Pro Max") { precio = 1100; imgSrc = "img/iphone16_promax.webp"; }
    }

    if (modeloSeleccionado === "iphone15") {
      if (versionSeleccionada === "Normal") { precio = 1000; imgSrc = "img/iphone15.webp"; }
      if (versionSeleccionada === "Pro") { precio = 1150; imgSrc = "img/iphone15_pro.jpg"; }
      if (versionSeleccionada === "Pro Max") { precio = 1300; imgSrc = "img/iphone_15_promax.jpg"; }
    }

    mensaje.textContent = `Has seleccionado ${modeloSeleccionado.toUpperCase()} ${versionSeleccionada}. Precio: $${precio}`;
    imagen.src = imgSrc;
  });
});

function volverPrincipal() {
  window.location.href = "index.html";
}