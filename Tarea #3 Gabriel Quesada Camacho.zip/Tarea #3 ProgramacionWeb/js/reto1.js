document.getElementById("btnConvertir").addEventListener("click", function () {
  const tipoCambio = parseFloat(document.getElementById("tipoCambio").value);
  const monto = parseFloat(document.getElementById("monto").value);
  const tipo = document.getElementById("conversion").value;
  const resultadoCampo = document.getElementById("resultado");

  if (isNaN(tipoCambio) || isNaN(monto) || tipoCambio <= 0) {
    alert("Por favor, ingrese valores válidos.");
    return;
  }

  let resultado;

  if (tipo === "c_to_d") {
    resultado = monto / tipoCambio;
    resultadoCampo.value = `$ ${resultado.toFixed(2)} USD`;
  } else {
    resultado = monto * tipoCambio;
    resultadoCampo.value = `₡ ${resultado.toFixed(2)} CRC`;
  }
});

function volverPrincipal() {
  window.location.href = "index.html"; 
}