document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("formVotacion");
  const mensaje = document.getElementById("mensaje");
  const reporte = document.getElementById("reporte");
  const btnReporte = document.getElementById("verReporte");
  const btnCerrar = document.getElementById("cerrarReporte");
  const btnInicio = document.getElementById("volverInicio");


  const votos = [];

  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const nombre = document.getElementById("nombre").value.trim();
    const cedula = document.getElementById("cedula").value.trim();
    const correo = document.getElementById("correo").value.trim();
    const nacimiento = document.getElementById("nacimiento").value;

    if (!nombre || !cedula || !correo || !nacimiento) {
      mensaje.textContent = " Por favor completa todos los campos.";
      mensaje.style.color = "orange";
      return;
    }

    const voto = { nombre, cedula, correo, nacimiento };
    votos.push(voto);

    mensaje.textContent = " Voto registrado con éxito. ¡Gracias por participar!";
    mensaje.style.color = "lightgreen";

    form.reset();
  });

  btnReporte.addEventListener("click", () => {
    if (votos.length === 0) {
      reporte.innerHTML = "<p>No hay votos registrados aún.</p>";
    } else {
      let html = `
        <table border="1" cellpadding="8" cellspacing="0">
          <tr>
            <th>Nombre</th>
            <th>Cédula</th>
            <th>Correo</th>
            <th>Año de nacimiento</th>
          </tr>
      `;
      votos.forEach(v => {
        html += `
          <tr>
            <td>${v.nombre}</td>
            <td>${v.cedula}</td>
            <td>${v.correo}</td>
            <td>${v.nacimiento}</td>
          </tr>
        `;
      });
      html += "</table>";
      reporte.innerHTML = html;
    }

    reporte.classList.remove("oculto");
    btnCerrar.classList.remove("oculto");
  });

  btnCerrar.addEventListener("click", () => {
    reporte.classList.add("oculto");
    btnCerrar.classList.add("oculto");
  });


  btnInicio.addEventListener("click", () => {
    window.location.href = "index.html"; 
  });
});
