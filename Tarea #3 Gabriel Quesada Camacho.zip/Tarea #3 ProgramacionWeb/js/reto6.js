document.addEventListener("DOMContentLoaded", function() {
  const colorBoxes = document.querySelectorAll(".color-box");
  const pradoImg = document.getElementById("pradoImg");
  const mensaje = document.getElementById("mensaje");

  const colores = {
    cafe: "img/prado_cafe.png",
    azul: "img/prado_azul.png",
    blanco: "img/prado_blanco.png",
    negro: "img/prado_negro.png"
  };

  colorBoxes.forEach(box => {
    box.addEventListener("click", function() {

      colorBoxes.forEach(b => b.classList.remove("active"));
      this.classList.add("active");

      const color = this.getAttribute("data-color");
      pradoImg.src = colores[color];
      mensaje.innerHTML = `Has elegido el color <strong>${color}</strong>.`;
    });
  });


  colorBoxes[0].classList.add("active");
});

function volverPrincipal() {
  window.location.href = "index.html";
}