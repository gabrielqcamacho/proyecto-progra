const AREAS = {
  salon: { nombre: "Salón de Eventos", tarifaHora: 5000, icono: "🎉" },
  piscina: { nombre: "Piscina (área privada)", tarifaHora: 2500, icono: "🏊" },
  gimnasio: { nombre: "Gimnasio", tarifaHora: 1000, icono: "🏋️" },
  bbq: { nombre: "Área de BBQ", tarifaHora: 3500, icono: "🍖" },
  jardin: { nombre: "Jardín para eventos", tarifaHora: 4000, icono: "🌳" },
  sala_reuniones: { nombre: "Sala de Reuniones", tarifaHora: 2000, icono: "💼" }
};

const STORAGE_KEY = "condominios_reservaciones";

function obtenerReservaciones() {
  const data = localStorage.getItem(STORAGE_KEY);
  return data ? JSON.parse(data) : [];
}

function guardarReservacion(reservacion) {
  const reservaciones = obtenerReservaciones();
  reservaciones.push(reservacion);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(reservaciones));
}

document.addEventListener('DOMContentLoaded', () => {
  emailjs.init('X-cn-LnRtCrKl7NYs');
  document.getElementById('reservationDate').setAttribute('min', new Date().toISOString().split('T')[0]);
  mostrarUltimaReservacion();
  
  document.getElementById('areaSelect').addEventListener('change', calcularCostos);
  document.getElementById('startTime').addEventListener('change', calcularCostos);
  document.getElementById('endTime').addEventListener('change', calcularCostos);
  document.getElementById('residentName').addEventListener('input', e => validarNombre(e.target.value));
  document.getElementById('residentUnit').addEventListener('input', e => validarUnidad(e.target.value));
  document.getElementById('residentEmail').addEventListener('input', e => validarEmail(e.target.value));
  document.getElementById('residentPhone').addEventListener('input', e => { formatearTelefono(e.target); validarTelefono(e.target.value); });
  document.getElementById('reservationDate').addEventListener('change', e => validarFecha(e.target.value));
});

function calcularHoras(inicio, fin) {
  if (!inicio || !fin) return 0;
  const [h1, m1] = inicio.split(':').map(Number);
  const [h2, m2] = fin.split(':').map(Number);
  const diff = (h2 * 60 + m2) - (h1 * 60 + m1);
  return diff > 0 ? diff / 60 : 0;
}

function calcularCostos() {
  const area = document.getElementById('areaSelect').value;
  const inicio = document.getElementById('startTime').value;
  const fin = document.getElementById('endTime').value;
  
  let tarifaHora = 0, horas = 0, total = 0;
  
  if (area && AREAS[area]) {
    tarifaHora = AREAS[area].tarifaHora;
    horas = calcularHoras(inicio, fin);
    total = tarifaHora * horas;
  }
  
  document.getElementById('hourlyRate').textContent = formatearMoneda(tarifaHora);
  document.getElementById('hoursCount').textContent = horas + ' horas';
  document.getElementById('totalCost').textContent = formatearMoneda(total);
  
  const feedback = document.getElementById('timeFeedback');
  if (inicio && fin && horas <= 0) {
    feedback.textContent = '⚠️ La hora de fin debe ser posterior al inicio';
    feedback.className = 'input-feedback error';
  } else if (horas > 0) {
    feedback.textContent = '✅ Horario válido';
    feedback.className = 'input-feedback success';
  } else {
    feedback.textContent = '';
  }
  
  return { tarifaHora, horas, total };
}

function formatearMoneda(valor) {
  return '₡' + valor.toLocaleString('es-CR');
}

function formatearTelefono(input) {
  let v = input.value.replace(/\D/g, '');
  if (v.length > 4) v = v.substring(0, 4) + '-' + v.substring(4, 8);
  input.value = v;
}

function validarNombre(valor) {
  const input = document.getElementById('residentName');
  const feedback = document.getElementById('nameFeedback');
  const valido = valor && valor.trim().length >= 3 && /^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/.test(valor);
  
  input.classList.toggle('is-valid', valido);
  input.classList.toggle('is-invalid', !valido && valor.length > 0);
  feedback.textContent = valido ? '✅ Válido' : (valor.length > 0 ? '⚠️ Mínimo 3 caracteres, solo letras' : '');
  feedback.className = 'input-feedback ' + (valido ? 'success' : 'error');
  return valido;
}

function validarUnidad(valor) {
  const input = document.getElementById('residentUnit');
  const feedback = document.getElementById('unitFeedback');
  const valido = valor && valor.trim().length >= 1;
  
  input.classList.toggle('is-valid', valido);
  input.classList.toggle('is-invalid', !valido && valor.length > 0);
  feedback.textContent = valido ? '✅ Válido' : '';
  feedback.className = 'input-feedback success';
  return valido;
}

function validarEmail(valor) {
  const input = document.getElementById('residentEmail');
  const feedback = document.getElementById('emailFeedback');
  const valido = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(valor);
  
  input.classList.toggle('is-valid', valido);
  input.classList.toggle('is-invalid', !valido && valor.length > 0);
  feedback.textContent = valido ? '✅ Válido' : (valor.length > 0 ? '⚠️ Formato inválido' : '');
  feedback.className = 'input-feedback ' + (valido ? 'success' : 'error');
  return valido;
}

function validarTelefono(valor) {
  const input = document.getElementById('residentPhone');
  const feedback = document.getElementById('phoneFeedback');
  const valido = /^\d{4}-\d{4}$/.test(valor);
  
  input.classList.toggle('is-valid', valido);
  input.classList.toggle('is-invalid', !valido && valor.length > 0);
  feedback.textContent = valido ? '✅ Válido' : (valor.length > 0 ? '⚠️ Formato: 8888-8888' : '');
  feedback.className = 'input-feedback ' + (valido ? 'success' : 'error');
  return valido;
}

function validarFecha(valor) {
  const input = document.getElementById('reservationDate');
  const feedback = document.getElementById('dateFeedback');
  const hoy = new Date(); hoy.setHours(0,0,0,0);
  const valido = valor && new Date(valor) >= hoy;
  
  input.classList.toggle('is-valid', valido);
  input.classList.toggle('is-invalid', !valido && valor);
  feedback.textContent = valido ? '✅ Válido' : (valor ? '⚠️ Fecha inválida' : '');
  feedback.className = 'input-feedback ' + (valido ? 'success' : 'error');
  return valido;
}

function crearReservacion() {
  const nombre = document.getElementById('residentName').value.trim();
  const unidad = document.getElementById('residentUnit').value.trim();
  const email = document.getElementById('residentEmail').value.trim();
  const telefono = document.getElementById('residentPhone').value.trim();
  const area = document.getElementById('areaSelect').value;
  const fecha = document.getElementById('reservationDate').value;
  const horaInicio = document.getElementById('startTime').value;
  const horaFin = document.getElementById('endTime').value;
  const invitados = document.getElementById('numGuests').value || 0;
  
  const v1 = validarNombre(nombre);
  const v2 = validarUnidad(unidad);
  const v3 = validarEmail(email);
  const v4 = validarTelefono(telefono);
  const v5 = validarFecha(fecha);
  const costos = calcularCostos();
  
  if (!v1 || !v2 || !v3 || !v4 || !v5 || !area || !horaInicio || !horaFin || costos.horas <= 0) {
    Swal.fire({ icon: 'error', title: '¡Campos incompletos!', text: 'Complete todos los campos correctamente.', confirmButtonColor: '#1b3039' });
    return;
  }
  
  const areaInfo = AREAS[area];
  const reservacion = {
    id: 'RES-' + Date.now(),
    nombre, unidad, email, telefono,
    area: areaInfo.nombre,
    icono: areaInfo.icono,
    fecha: formatearFechaLegible(fecha),
    horaInicio: formatearHora(horaInicio),
    horaFin: formatearHora(horaFin),
    horas: costos.horas,
    invitados: parseInt(invitados),
    tarifaHora: costos.tarifaHora,
    total: costos.total
  };
  
  mostrarDetallesReservacion(reservacion);
  guardarReservacion(reservacion);
  enviarCorreo(reservacion);
  limpiarFormulario();
  
  Swal.fire({
    icon: 'success',
    title: '¡Reservación Confirmada!',
    html: `<p>Se enviará un correo de confirmación a <strong>${email}</strong></p>`,
    confirmButtonColor: '#4CAF50'
  });
}

function mostrarDetallesReservacion(res) {
  document.getElementById('reservationDetails').innerHTML = `
    <div class="reservation-confirmed">
      <div class="text-center">
        <span class="status-badge">✅ Reservación Confirmada</span>
      </div>
      <div class="detail-row"><span class="detail-label">ID Reservación</span><span class="detail-value">${res.id}</span></div>
      <div class="detail-row"><span class="detail-label">👤 Residente</span><span class="detail-value">${res.nombre}</span></div>
      <div class="detail-row"><span class="detail-label">🏠 Unidad</span><span class="detail-value">${res.unidad}</span></div>
      <div class="detail-row"><span class="detail-label">📧 Correo</span><span class="detail-value">${res.email}</span></div>
      <div class="detail-row"><span class="detail-label">📞 Teléfono</span><span class="detail-value">${res.telefono}</span></div>
      <div class="detail-row"><span class="detail-label">${res.icono} Área</span><span class="detail-value">${res.area}</span></div>
      <div class="detail-row"><span class="detail-label">📅 Fecha</span><span class="detail-value">${res.fecha}</span></div>
      <div class="detail-row"><span class="detail-label">🕐 Horario</span><span class="detail-value">${res.horaInicio} - ${res.horaFin}</span></div>
      <div class="detail-row"><span class="detail-label">⏱️ Duración</span><span class="detail-value">${res.horas} horas</span></div>
      <div class="detail-row"><span class="detail-label">👥 Invitados</span><span class="detail-value">${res.invitados}</span></div>
      <div class="detail-row"><span class="detail-label">💵 Tarifa/hora</span><span class="detail-value">${formatearMoneda(res.tarifaHora)}</span></div>
      <div class="total-row detail-row"><span class="detail-label">💰 TOTAL</span><span class="detail-value">${formatearMoneda(res.total)}</span></div>
    </div>
  `;
}

function enviarCorreo(res) {
  const form = document.createElement('form');
  form.innerHTML = `
    <input type="hidden" name="to_name" value="${res.nombre}">
    <input type="hidden" name="to_email" value="${res.email}">
    <input type="hidden" name="reservation_id" value="${res.id}">
    <input type="hidden" name="area" value="${res.area}">
    <input type="hidden" name="fecha" value="${res.fecha}">
    <input type="hidden" name="horario" value="${res.horaInicio} - ${res.horaFin}">
    <input type="hidden" name="horas" value="${res.horas}">
    <input type="hidden" name="total" value="${formatearMoneda(res.total)}">
    <input type="hidden" name="unidad" value="${res.unidad}">
  `;
  
  emailjs.sendForm('service_irg6zyc', 'template_yjfr6bu', form, 'wIZvcoK8lJmVIhEsu')
    .then(() => console.log('Correo enviado'))
    .catch(err => console.log('Error al enviar correo:', err));
}

function limpiarFormulario() {
  ['residentName', 'residentUnit', 'residentEmail', 'residentPhone', 'reservationDate'].forEach(id => {
    document.getElementById(id).value = '';
    document.getElementById(id).classList.remove('is-valid', 'is-invalid');
  });
  document.getElementById('areaSelect').value = '';
  document.getElementById('startTime').value = '';
  document.getElementById('endTime').value = '';
  document.getElementById('numGuests').value = '0';
  document.querySelectorAll('.input-feedback').forEach(el => { el.textContent = ''; el.className = 'input-feedback'; });
  document.getElementById('hourlyRate').textContent = '₡0';
  document.getElementById('hoursCount').textContent = '0 horas';
  document.getElementById('totalCost').textContent = '₡0';
}

function formatearFechaLegible(fecha) {
  return new Date(fecha + 'T00:00:00').toLocaleDateString('es-CR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
}

function formatearHora(hora) {
  const [h, m] = hora.split(':');
  return (h > 12 ? h - 12 : h) + ':' + m + ' ' + (h >= 12 ? 'PM' : 'AM');
}

function mostrarUltimaReservacion() {
  const reservaciones = obtenerReservaciones();
  if (reservaciones.length > 0) {
    const ultima = reservaciones[reservaciones.length - 1];
    mostrarDetallesReservacion(ultima);
  }
}