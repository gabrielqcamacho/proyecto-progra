function animarContador(elemento, inicio, fin, duracion) {
  let startTimestamp = null;
  const step = (timestamp) => {
    if (!startTimestamp) startTimestamp = timestamp;
    const progress = Math.min((timestamp - startTimestamp) / duracion, 1);
    const valor = Math.floor(progress * (fin - inicio) + inicio);
    elemento.textContent = valor.toLocaleString();
    if (progress < 1) {
      window.requestAnimationFrame(step);
    }
  };
  window.requestAnimationFrame(step);
}

const observerOptions = {
  threshold: 0.5,
  rootMargin: '0px'
};

const contadorObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting && !entry.target.classList.contains('animated')) {
      entry.target.classList.add('animated');
      
      const statNumbers = entry.target.querySelectorAll('.stat-number');
      statNumbers.forEach(stat => {
        const target = parseInt(stat.getAttribute('data-target'));
        animarContador(stat, 0, target, 2000);
      });
      
      const provinceFills = entry.target.querySelectorAll('.province-fill');
      provinceFills.forEach(fill => {
        const targetWidth = fill.getAttribute('data-width');
        const numberElement = fill.querySelector('.province-number');
        const targetNumber = parseInt(numberElement.getAttribute('data-target'));
        
        setTimeout(() => {
          fill.style.width = targetWidth + '%';
          animarContador(numberElement, 0, targetNumber, 2000);
        }, 200);
      });
    }
  });
}, observerOptions);

let currentTestimonial = 0;
let testimonialSlides;
let dots;
let testimonialInterval;

function mostrarTestimonial(index) {
  testimonialSlides.forEach(slide => slide.classList.remove('active'));
  dots.forEach(dot => dot.classList.remove('active'));
  
  if (index >= testimonialSlides.length) {
    currentTestimonial = 0;
  } else if (index < 0) {
    currentTestimonial = testimonialSlides.length - 1;
  } else {
    currentTestimonial = index;
  }
  
  testimonialSlides[currentTestimonial].classList.add('active');
  dots[currentTestimonial].classList.add('active');
}

function cambiarTestimonial(direction) {
  mostrarTestimonial(currentTestimonial + direction);
}

function irATestimonial(index) {
  mostrarTestimonial(index);
}

function iniciarAutoTestimonial() {
  testimonialInterval = setInterval(() => {
    cambiarTestimonial(1);
  }, 5000);
}

function detenerAutoTestimonial() {
  clearInterval(testimonialInterval);
}

function reiniciarEncuesta() {
  const surveyForm = document.getElementById('surveyForm');
  const thankYou = document.getElementById('surveyThankYou');
  
  surveyForm.reset();
  surveyForm.style.display = 'block';
  thankYou.style.display = 'none';
  
  surveyForm.scrollIntoView({ 
    behavior: 'smooth',
    block: 'start'
  });
}

document.addEventListener('DOMContentLoaded', function() {
  const statsSection = document.querySelector('.stats-section');
  if (statsSection) {
    contadorObserver.observe(statsSection);
  }

  testimonialSlides = document.querySelectorAll('.testimonial-slide');
  dots = document.querySelectorAll('.dot');
  
  if (testimonialSlides.length > 0) {
    iniciarAutoTestimonial();
    
    const testimonialContainer = document.querySelector('.testimonial-container');
    if (testimonialContainer) {
      testimonialContainer.addEventListener('mouseenter', detenerAutoTestimonial);
      testimonialContainer.addEventListener('mouseleave', iniciarAutoTestimonial);
    }
  }

  const surveyForm = document.getElementById('surveyForm');
  
  if (surveyForm) {
    surveyForm.addEventListener('submit', function(e) {
      e.preventDefault();
      
      const formData = new FormData(surveyForm);
      
      if (!formData.get('quality') || !formData.get('amenities') || 
          !formData.get('valued_aspect') || !formData.get('recommend')) {
        alert('Por favor completa todas las preguntas requeridas.');
        return;
      }
      
      const submitBtn = surveyForm.querySelector('.btn-submit');
      const originalText = submitBtn.textContent;
      submitBtn.disabled = true;
      submitBtn.textContent = 'Enviando...';
      
      emailjs.sendForm('service_h6uocbb', 'template_a8sg76f', '#surveyForm', 'wIZvcoK8lJmVIhEsu')
      .then(function(response) {
        console.log('Email enviado exitosamente!', response.status, response.text);
        
        const surveyData = {
          quality: formData.get('quality'),
          amenities: formData.get('amenities'),
          valued_aspect: formData.get('valued_aspect'),
          recommend: formData.get('recommend'),
          suggestions: formData.get('suggestions'),
          name: formData.get('name'),
          email: formData.get('email'),
          timestamp: new Date().toLocaleString('es-CR')
        };
        
        let surveys = JSON.parse(localStorage.getItem('surveys') || '[]');
        surveys.push(surveyData);
        localStorage.setItem('surveys', JSON.stringify(surveys));
        
        surveyForm.style.display = 'none';
        document.getElementById('surveyThankYou').style.display = 'block';
        
        document.getElementById('surveyThankYou').scrollIntoView({ 
          behavior: 'smooth',
          block: 'center'
        });
      })
      .catch(function(error) {
        console.error('Error al enviar email:', error);
        alert('Hubo un error al enviar la encuesta. Por favor intenta nuevamente.');
        submitBtn.disabled = false;
        submitBtn.textContent = originalText;
      });
    });
  }

  const fadeElements = document.querySelectorAll('.info-card, .stat-card, .testimonial-card');
  
  const fadeObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '0';
        entry.target.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
          entry.target.style.transition = 'all 0.6s ease';
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
        }, 100);
      }
    });
  }, { threshold: 0.1 });
  
  fadeElements.forEach(element => {
    fadeObserver.observe(element);
  });
});