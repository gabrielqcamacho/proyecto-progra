
function mostrarDescripcion(event, area) {
  event.preventDefault(); 
  const card = document.getElementById("descripcionCard");

  let titulo = "", descripcion = "";
  switch(area) {
    case "1":
      titulo = "Cancha de Tenis";
      descripcion = "Amplia cancha de tenis profesional para eventos y recreación familiar.";
      break;
    case "2":
      titulo = "Parque Infantil";
      descripcion = "Zona segura con columpios, toboganes y juegos para los más pequeños.";
      break;
    case "3":
      titulo = "Piscina";
      descripcion = "Piscina con secciones para adultos y niños.";
      break;
    case "4":
      titulo = "Gimnasio";
      descripcion = "Equipado con máquinas para toda la familia.";
      break;
    case "5":
      titulo = "Ranchos y Áreas Verdes";
      descripcion = "Ranchos, parrillas y jardines familiares.";
      break;
  }

  card.innerHTML = `<h4>${titulo}</h4><p>${descripcion}</p>`;
                    
  const mapa = document.getElementById("mapa");
  const rect = mapa.getBoundingClientRect();

  let x = event.clientX - rect.left + 10; 
  let y = event.clientY - rect.top - 50;  

 
  const cardWidth = 280;
  const cardHeight = card.offsetHeight || 120; 
  if (x + cardWidth > rect.width) x = rect.width - cardWidth - 10;
  if (y + cardHeight > rect.height) y = rect.height - cardHeight - 10;
  if (y < 0) y = 5;

  card.style.left = x + 'px';
  card.style.top = y + 'px';
  card.style.display = "block";
}


function volverPrincipal() {
  window.location.href = "inicio.html";
}


document.addEventListener('DOMContentLoaded', function() {
  const carouselElement = document.getElementById('carouselCondominio');
  
  if (carouselElement) {
    const carousel = new bootstrap.Carousel(carouselElement, {
      interval: 4000,  
      wrap: true,      
      pause: 'hover'  
    });
  }
});