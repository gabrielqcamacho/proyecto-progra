
window.addEventListener("load", function () {

  if (typeof viewer === "undefined" || typeof panorama1 === "undefined" || typeof panorama2 === "undefined") {
    console.warn("No se encontró el viewer o los panoramas.");
    return;
  }

  console.log("Mapper activado correctamente.");

  function getPosition(viewer) {
    const intersects = viewer.raycaster.intersectObject(viewer.panorama, true);
    return intersects.length ? intersects[0].point : null;
  }

  panorama1.addEventListener("click", function () {
    const pos = getPosition(viewer);
    if (!pos) return;

    const x = Math.round(pos.x);
    const y = Math.round(pos.y);
    const z = Math.round(pos.z);

    console.log(`Panorama 1 → x:${x}, y:${y}, z:${z}`);


    const coords = `${x}, ${y}, ${z}`;
    navigator.clipboard.writeText(coords).then(() => {
      alert(`Coordenadas Panorama 1:\n(${coords})\nCopiadas al portapapeles`);
    }).catch(() => {
      alert(`Coordenadas Panorama 1:\n(${coords})`);
    });
  });

  panorama2.addEventListener("click", function () {
    const pos = getPosition(viewer);
    if (!pos) return;

    const x = Math.round(pos.x);
    const y = Math.round(pos.y);
    const z = Math.round(pos.z);

    console.log(`Panorama 2 → x:${x}, y:${y}, z:${z}`);

    const coords = `${x}, ${y}, ${z}`;
    navigator.clipboard.writeText(coords).then(() => {
      alert(`Coordenadas Panorama 2:\n(${coords})\nCopiadas al portapapeles`);
    }).catch(() => {
      alert(`Coordenadas Panorama 2:\n(${coords})`);
    });
  });

});