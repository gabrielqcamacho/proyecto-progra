let propiedadesData = [];
let vistaActual = 'grid';

async function cargarPropiedades() {
  try {
    const response = await fetch('propiedades.json');
    const data = await response.json();
    propiedadesData = data.propiedades;
    mostrarPropiedades(propiedadesData);
  } catch (error) {
    console.error('Error cargando propiedades:', error);
  }
}

function mostrarPropiedades(propiedades) {
  const container = document.getElementById('catalogoContainer');
  container.innerHTML = '';
  
  propiedades.forEach(prop => {
    const div = document.createElement('div');
    div.className = 'property-item';
    div.setAttribute('data-provincia', prop.provincia);
    div.onclick = () => abrirDetalles(prop);
    
    div.innerHTML = `
      <div class="property-item-image">
        <img src="${prop.imagen}" alt="${prop.nombre}">
        ${prop.nuevo ? '<span class="property-badge-new">Nuevo</span>' : ''}
        <div class="property-heart" onclick="event.stopPropagation(); toggleFavorito(this, ${prop.id})">
          ♡
        </div>
      </div>
      <div class="property-item-content">
        <h4 class="property-item-title">${prop.nombre}</h4>
        <p class="property-item-location">${prop.ubicacion}</p>
        <div class="property-item-features">
          <span class="property-feature feature-beds">${prop.habitaciones} Hab</span>
          <span class="property-feature feature-baths">${prop.banos} Baños</span>
          <span class="property-feature feature-area">${prop.area} m²</span>
        </div>
        <div class="property-item-price">$${prop.precio.toLocaleString()}</div>
        <button class="property-item-btn">Ver Detalles</button>
      </div>
    `;
    
    container.appendChild(div);
  });
}

function abrirDetalles(prop) {
  document.getElementById('modalTitle').textContent = prop.nombre;
  document.getElementById('modalImage').src = prop.imagen;
  
  document.getElementById('tabGeneralTitle').textContent = prop.nombre;
  document.getElementById('tabGeneralDesc').textContent = prop.descripcion;
  document.getElementById('tabTipo').textContent = prop.tipo.charAt(0).toUpperCase() + prop.tipo.slice(1);
  document.getElementById('tabPrecio').textContent = `$${prop.precio.toLocaleString()}`;
  
  document.getElementById('tabHabitaciones').textContent = prop.habitaciones;
  document.getElementById('tabBanos').textContent = prop.banos;
  document.getElementById('tabArea').textContent = prop.area;
  
  const amenidadesList = document.getElementById('tabAmenidades');
  amenidadesList.innerHTML = '';
  prop.amenidades.forEach(amenidad => {
    const li = document.createElement('li');
    li.textContent = amenidad;
    amenidadesList.appendChild(li);
  });
  
  document.getElementById('tabUbicacion').textContent = prop.ubicacion;
  
  const modal = new bootstrap.Modal(document.getElementById('propertyModal'));
  modal.show();
}

function toggleFavorito(element, id) {
  console.log('Favorito:', id);
  element.textContent = element.textContent === '♡' ? '♥' : '♡';
}

function cambiarVista(vista) {
  vistaActual = vista;
  const container = document.getElementById('catalogoContainer');
  const btnGrid = document.getElementById('btnGrid');
  const btnList = document.getElementById('btnList');
  
  if (vista === 'grid') {
    container.classList.remove('list-view');
    btnGrid.classList.add('active');
    btnList.classList.remove('active');
  } else {
    container.classList.add('list-view');
    btnList.classList.add('active');
    btnGrid.classList.remove('active');
  }
}

function filtrarPorProvincia(provincia) {
  const buttons = document.querySelectorAll('.filter-tag');
  buttons.forEach(btn => btn.classList.remove('active'));
  event.target.classList.add('active');
  
  if (provincia === '') {
    mostrarPropiedades(propiedadesData);
  } else {
    const filtradas = propiedadesData.filter(p => p.provincia === provincia);
    mostrarPropiedades(filtradas);
  }
}

document.addEventListener('DOMContentLoaded', function() {
  cargarPropiedades();
  
  const sortBy = document.getElementById('sortBy');
  if (sortBy) {
    sortBy.addEventListener('change', function() {
      let sorted = [...propiedadesData];
      
      switch(this.value) {
        case 'price-asc':
          sorted.sort((a, b) => a.precio - b.precio);
          break;
        case 'price-desc':
          sorted.sort((a, b) => b.precio - a.precio);
          break;
        case 'newest':
          sorted.sort((a, b) => (b.nuevo ? 1 : 0) - (a.nuevo ? 1 : 0));
          break;
        case 'area-desc':
          sorted.sort((a, b) => b.area - a.area);
          break;
        case 'rooms-desc':
          sorted.sort((a, b) => b.habitaciones - a.habitaciones);
          break;
        default:
          sorted = propiedadesData;
      }
      
      mostrarPropiedades(sorted);
    });
  }
  
  const container = document.querySelector('#container_secundario');
  container.style.minHeight = '70vh';
  container.style.display = 'none';
  
  const viewer = new PANOLENS.Viewer({
    container: container,
    autoHideInfospot: false,
    controlBar: true,
    autoRotate: false,
    autoRotateSpeed: 0.3
  });

  window.addEventListener('resize', () => {
    try { 
      viewer.onWindowResize(); 
    } catch (e) {
      console.warn('Error al redimensionar viewer:', e);
    }
  });

  const panorama1 = new PANOLENS.ImagePanorama('img/img casa 2.jpg');
  
  var p1_video = new PANOLENS.Infospot(50, PANOLENS.DataImage.Info);
  p1_video.position.set(-473, -158, -42);
  p1_video.addHoverText('Ver video del condominio', -60);
  p1_video.element.innerHTML = '<div style="background:rgba(0,0,0,0.85); color:#fff; padding:8px; border-radius:6px; width:200px; font-size:13px;">Ver video del recorrido — haz clic para abrir.</div>';
  p1_video.addEventListener('click', function () {
    window.open('https://www.youtube.com/watch?v=fokXMm_-vDw', '_blank');
  });
  panorama1.add(p1_video);

  var p1_alert = new PANOLENS.Infospot(50, PANOLENS.DataImage.Info);
  p1_alert.position.set(320, -120, 480);
  p1_alert.addHoverText('Información del condominio', -60);
  p1_alert.element.innerHTML = '<div style="background:rgba(0,0,0,0.85); color:#fff; padding:8px; border-radius:6px; width:200px; font-size:13px;">Información general — haz clic para más detalles.</div>';
  p1_alert.addEventListener('click', function () {
    Swal.fire({
      title: 'Condominio Vista Verde',
      text: 'Áreas verdes, piscina, seguridad 24/7 y acabados de primera.',
      icon: 'info',
      confirmButtonText: 'Cerrar'
    });
  });
  panorama1.add(p1_alert);

  var p1_sillon = new PANOLENS.Infospot(50, PANOLENS.DataImage.Info);
  p1_sillon.position.set(489, -98, 499);
  p1_sillon.addHoverText('Sala principal', -60);
  p1_sillon.element.innerHTML = '<div style="background:rgba(0,0,0,0.85); color:#fff; padding:8px; border-radius:6px; width:200px; font-size:13px;"><strong>Sala principal</strong><br>Diseño moderno y gran comodidad, perfecta para disfrutar en familia</div>';
  panorama1.add(p1_sillon);

  var p1_cuarto = new PANOLENS.Infospot(50, PANOLENS.DataImage.Info);
  p1_cuarto.position.set(-350, -120, 480);
  p1_cuarto.addHoverText('Cuarto principal', -60);
  p1_cuarto.element.innerHTML = '<div style="background:rgba(0,0,0,0.85); color:#fff; padding:8px; border-radius:6px; width:200px; font-size:13px;"><strong>Cuarto principal</strong><br>Amplio, con buena entrada de luz y baño privado.</div>';
  panorama1.add(p1_cuarto);

  var p1_bano = new PANOLENS.Infospot(50, PANOLENS.DataImage.Info);
  p1_bano.position.set(-288, 150, -123);
  p1_bano.addHoverText('Vistas', -60);
  p1_bano.element.innerHTML = '<div style="background:rgba(0,0,0,0.85); color:#fff; padding:8px; border-radius:6px; width:200px; font-size:13px;"><strong>Vistas</strong><br>Disfrute de una hermosa vista desde su sala y su balcón.</div>';
  panorama1.add(p1_bano);

  const panorama2 = new PANOLENS.ImagePanorama('img/Casa2-360.jpg');
  
  var p2_pdf = new PANOLENS.Infospot(50, PANOLENS.DataImage.Info);
  p2_pdf.position.set(400, -120, 500);
  p2_pdf.addHoverText('Abrir folleto (PDF)', -60);
  p2_pdf.element.innerHTML = '<div style="background:rgba(0,0,0,0.85); color:#fff; padding:8px; border-radius:6px; width:200px; font-size:13px;">Descripción del granito — haz clic para abrir.</div>';
  p2_pdf.addEventListener('click', function () {
    window.open('pdf/Folleto_Granito_Cocina.pdf', '_blank');
  });
  panorama2.add(p2_pdf);

  var p2_audio = new PANOLENS.Infospot(50, PANOLENS.DataImage.Info);
  p2_audio.position.set(-480, -100, 490);
  p2_audio.addHoverText('Reproducir audio', -60);
  p2_audio.element.innerHTML = '<div style="background:rgba(0,0,0,0.85); color:#fff; padding:8px; border-radius:6px; width:200px; font-size:13px;">Audio descriptivo — haz clic para reproducir.</div>';
  p2_audio.addEventListener('click', function () {
    try {
      var audio = new Audio('audio/tour.mp3');
      audio.play();
    } catch (err) {
      console.warn('Error reproduciendo audio:', err);
    }
  });
  panorama2.add(p2_audio);

  var p2_imgtxt = new PANOLENS.Infospot(50, PANOLENS.DataImage.Info);
  p2_imgtxt.position.set(500, -50, -480);
  p2_imgtxt.addHoverText('Cocina moderna', -60);
  p2_imgtxt.element.innerHTML = '<div style="background:rgba(0,0,0,0.85); color:#fff; padding:8px; border-radius:6px; width:220px; font-size:13px;"><img src="img/granito.webp" style="width:100%; border-radius:4px; margin-bottom:6px;"><strong>Cocina</strong><br>Amplia, con muebles empotrados y granito.</div>';
  p2_imgtxt.add(p2_imgtxt);

  var p2_simple1 = new PANOLENS.Infospot(50, PANOLENS.DataImage.Info);
  p2_simple1.position.set(300, -50, 400);
  p2_simple1.addHoverText('Sala principal', -60);
  p2_simple1.element.innerHTML = '<div style="background:rgba(0,0,0,0.85); color:#fff; padding:8px; border-radius:6px; width:200px; font-size:13px;">Sala cómoda y espaciosa, ideal para reuniones familiares.</div>';
  panorama2.add(p2_simple1);

  var p2_simple2 = new PANOLENS.Infospot(50, PANOLENS.DataImage.Info);
  p2_simple2.position.set(-450, -120, -500);
  p2_simple2.addHoverText('Artefactos', -60);
  p2_simple2.element.innerHTML = '<div style="background:rgba(0,0,0,0.85); color:#fff; padding:8px; border-radius:6px; width:200px; font-size:13px;">Disfrute de su futura cocina, equipada con los artefactos más modernos.</div>';
  panorama2.add(p2_simple2);

  viewer.add(panorama1, panorama2);

  const botones = document.querySelectorAll('.btn-ver-tour');

  botones.forEach((boton) => {
    boton.addEventListener('click', (e) => {
      const seleccion = e.target.getAttribute('data-tour');
      container.style.display = 'block';

      setTimeout(() => {
        if (seleccion === 'tour1') {
          viewer.setPanorama(panorama1);
        } else if (seleccion === 'tour2') {
          viewer.setPanorama(panorama2);
        }

        try { 
          viewer.onWindowResize(); 
        } catch (err) {}
      }, 100);

      setTimeout(() => {
        window.scrollTo({ 
          top: container.offsetTop - 50, 
          behavior: 'smooth' 
        });
      }, 150);
    });
  });
});