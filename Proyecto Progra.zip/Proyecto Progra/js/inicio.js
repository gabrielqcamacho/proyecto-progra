const translations = {
  es: {
    companyName: "Condominios Residenciales",
    navHome: "Inicio",
    navAbout: "Nosotros",
    navModels: "Modelos",
    navAmenities: "Amenidades",
    navGallery: "Galería",
    navContact: "Contáctenos",
    btnSchedule: "Agendar cita",
    heroTitle: "Condominios Residenciales",
    heroSubtitle: "Toda la información de condominios en un solo lugar",
    searchPlaceholder: "Buscar por nombre, ubicación o precio...",
    btnSearch: "🔍 Buscar",
    videoBadge: "🎥 Video Tour",
    videoTitle: "Descubre Tu Futuro Hogar",
    videoText: "Explora virtualmente nuestros exclusivos condominios y conoce cada detalle que hace especial a nuestras comunidades. Vive la experiencia de tu nuevo hogar desde la comodidad de tu dispositivo.",
    videoFeature1: "Tour 360° de todas las áreas",
    videoFeature2: "Conoce nuestras amenidades",
    videoFeature3: "Recorre espacios interiores y exteriores",
    videoFeature4: "Testimonios de nuestros residentes",
    videoBtn: "Ver Más Proyectos →",
    videoOverlay: "Haz clic para ver el video",
    filterTitle: "Filtrar Propiedades",
    filterLocation: "Ubicación:",
    filterType: "Tipo:",
    filterPrice: "Precio máximo:",
    filterAllLocations: "Todas las ubicaciones",
    filterAllTypes: "Todos los tipos",
    filterNoLimit: "Sin límite",
    filterUpTo200: "Hasta $200,000",
    filterUpTo400: "Hasta $400,000",
    filterUpTo600: "Hasta $600,000",
    filterTypeHouse: "Casa",
    filterTypeApartment: "Apartamento",
    btnApplyFilters: "Aplicar Filtros",
    btnClearFilters: "Limpiar",
    newHousesTitle: "Casas Nuevas",
    newHousesText: "Conozca todas las casas que tenemos para ofrecerte, adecuadas para todo tipo de familias y necesidades, además de todas las amenidades que las rodean.",
    apartmentsTitle: "Apartamentos",
    apartmentsText: "Descubre los increíbles apartamentos que tenemos disponibles y todos los servicios que podrás disfrutar dentro del mismo edificio.",
    btnLearnMore: "Conoce más",
    propertiesTitle: "Nuestras Propiedades Disponibles",
    propertiesSubtitle: "Encuentra el hogar perfecto para ti y tu familia",
    badgeNew: "Nuevo",
    propertyHab: "Hab",
    propertyBaths: "Baños",
    propertyBtn: "Ver Detalles",
    footerRights: "Todos los derechos reservados 2025",
    noResults: "No se encontraron propiedades con esos criterios.",
    searchResults: "resultados encontrados",
    alertSearchEmpty: "Por favor ingrese un término de búsqueda"
  },
  en: {
    companyName: "Residential Condominiums",
    navHome: "Home",
    navAbout: "About Us",
    navModels: "Models",
    navAmenities: "Amenities",
    navGallery: "Gallery",
    navContact: "Contact Us",
    btnSchedule: "Schedule Appointment",
    heroTitle: "Residential Condominiums",
    heroSubtitle: "All condominium information in one place",
    searchPlaceholder: "Search by name, location or price...",
    btnSearch: "🔍 Search",
    videoBadge: "🎥 Video Tour",
    videoTitle: "Discover Your Future Home",
    videoText: "Virtually explore our exclusive condominiums and discover every detail that makes our communities special. Experience your new home from the comfort of your device.",
    videoFeature1: "360° tour of all areas",
    videoFeature2: "Discover our amenities",
    videoFeature3: "Tour interior and exterior spaces",
    videoFeature4: "Testimonials from our residents",
    videoBtn: "See More Projects →",
    videoOverlay: "Click to watch video",
    filterTitle: "Filter Properties",
    filterLocation: "Location:",
    filterType: "Type:",
    filterPrice: "Maximum price:",
    filterAllLocations: "All locations",
    filterAllTypes: "All types",
    filterNoLimit: "No limit",
    filterUpTo200: "Up to $200,000",
    filterUpTo400: "Up to $400,000",
    filterUpTo600: "Up to $600,000",
    filterTypeHouse: "House",
    filterTypeApartment: "Apartment",
    btnApplyFilters: "Apply Filters",
    btnClearFilters: "Clear",
    newHousesTitle: "New Houses",
    newHousesText: "Discover all the houses we have to offer, suitable for all types of families and needs, plus all the amenities that surround them.",
    apartmentsTitle: "Apartments",
    apartmentsText: "Discover the amazing apartments we have available and all the services you can enjoy within the same building.",
    btnLearnMore: "Learn More",
    propertiesTitle: "Our Available Properties",
    propertiesSubtitle: "Find the perfect home for you and your family",
    badgeNew: "New",
    propertyHab: "Bed",
    propertyBaths: "Baths",
    propertyBtn: "View Details",
    footerRights: "All rights reserved 2025",
    noResults: "No properties found with those criteria.",
    searchResults: "results found",
    alertSearchEmpty: "Please enter a search term"
  }
};

let currentLanguage = 'es';
let propiedadesData = [];

document.addEventListener('DOMContentLoaded', function() {
  const languageToggle = document.getElementById('languageToggle');
  
  if (languageToggle) {
    languageToggle.addEventListener('change', function() {
      currentLanguage = this.checked ? 'en' : 'es';
      translatePage();
    });
  }

  cargarPropiedades();
});

function translatePage() {
  const elements = document.querySelectorAll('[data-translate]');
  
  elements.forEach(element => {
    const key = element.getAttribute('data-translate');
    if (translations[currentLanguage][key]) {
      if (element.tagName === 'OPTION') {
        element.textContent = translations[currentLanguage][key];
      } else {
        element.textContent = translations[currentLanguage][key];
      }
    }
  });
  
  const searchInput = document.getElementById('searchInput');
  if (searchInput) {
    searchInput.placeholder = translations[currentLanguage].searchPlaceholder;
  }

  mostrarPropiedades(propiedadesData);
}

async function cargarPropiedades() {
  try {
    const response = await fetch('propiedades.json');
    const data = await response.json();
    propiedadesData = data.propiedades;
    mostrarPropiedades(propiedadesData);
  } catch (error) {
    console.error('Error cargando propiedades:', error);
  }
}

function mostrarPropiedades(propiedades) {
  const container = document.getElementById('propertiesContainer');
  container.innerHTML = '';
  
  propiedades.forEach(prop => {
    const col = document.createElement('div');
    col.className = 'col-12 col-sm-6 col-md-4 col-lg-3 property-card';
    col.setAttribute('data-location', prop.provincia);
    col.setAttribute('data-type', prop.tipo);
    col.setAttribute('data-price', prop.precio);
    col.setAttribute('data-name', prop.nombre);
    
    col.innerHTML = `
      <div class="property-card-inner">
        <div class="property-image">
          <img src="${prop.imagen}" alt="${prop.nombre}">
          ${prop.nuevo ? `<span class="property-badge" data-translate="badgeNew">${translations[currentLanguage].badgeNew}</span>` : ''}
        </div>
        <div class="property-details">
          <h4 class="property-title">${prop.nombre}</h4>
          <p class="property-location">${prop.ubicacion}</p>
          <div class="property-features">
            <span class="feature-item feature-beds">${prop.habitaciones} <span data-translate="propertyHab">${translations[currentLanguage].propertyHab}</span></span>
            <span class="feature-item feature-baths">${prop.banos} <span data-translate="propertyBaths">${translations[currentLanguage].propertyBaths}</span></span>
            <span class="feature-item feature-area">${prop.area} m²</span>
          </div>
          <div class="property-price">${prop.precio.toLocaleString()}</div>
          <a href="modelos.html?id=${prop.id}" class="property-btn" data-translate="propertyBtn">${translations[currentLanguage].propertyBtn}</a>
        </div>
      </div>
    `;
    
    container.appendChild(col);
  });
}

function buscarPropiedad() {
  const searchTerm = document.getElementById('searchInput').value.toLowerCase();
  
  if (searchTerm.trim() === '') {
    alert(translations[currentLanguage].alertSearchEmpty);
    return;
  }
  
  const properties = document.querySelectorAll('.property-card');
  let foundCount = 0;
  
  properties.forEach(property => {
    const name = property.getAttribute('data-name').toLowerCase();
    const location = property.textContent.toLowerCase();
    const price = property.getAttribute('data-price');
    
    if (name.includes(searchTerm) || 
        location.includes(searchTerm) || 
        price.includes(searchTerm)) {
      property.classList.remove('hidden');
      property.classList.add('highlight');
      foundCount++;
      
      setTimeout(() => {
        property.classList.remove('highlight');
      }, 1000);
    } else {
      property.classList.add('hidden');
    }
  });
  
  if (foundCount === 0) {
    alert(translations[currentLanguage].noResults);
    limpiarBusqueda();
  } else {
    document.querySelector('.houses-section').scrollIntoView({ 
      behavior: 'smooth',
      block: 'start'
    });
  }
}

function limpiarBusqueda() {
  document.getElementById('searchInput').value = '';
  const properties = document.querySelectorAll('.property-card');
  properties.forEach(property => {
    property.classList.remove('hidden');
    property.classList.remove('highlight');
  });
}

document.addEventListener('DOMContentLoaded', function() {
  const searchInput = document.getElementById('searchInput');
  if (searchInput) {
    searchInput.addEventListener('keypress', function(e) {
      if (e.key === 'Enter') {
        buscarPropiedad();
      }
    });
  }
});

function aplicarFiltros() {
  const location = document.getElementById('filterLocation').value.toLowerCase();
  const type = document.getElementById('filterType').value.toLowerCase();
  const maxPrice = document.getElementById('filterPrice').value;
  
  const properties = document.querySelectorAll('.property-card');
  let foundCount = 0;
  
  properties.forEach(property => {
    const propLocation = property.getAttribute('data-location').toLowerCase();
    const propType = property.getAttribute('data-type').toLowerCase();
    const propPrice = parseInt(property.getAttribute('data-price'));
    
    let showProperty = true;
    
    if (location && propLocation !== location) {
      showProperty = false;
    }
    
    if (type && propType !== type) {
      showProperty = false;
    }
    
    if (maxPrice && propPrice > parseInt(maxPrice)) {
      showProperty = false;
    }
    
    if (showProperty) {
      property.classList.remove('hidden');
      property.classList.add('highlight');
      foundCount++;
      
      setTimeout(() => {
        property.classList.remove('highlight');
      }, 1000);
    } else {
      property.classList.add('hidden');
    }
  });
  
  if (foundCount === 0) {
    alert(translations[currentLanguage].noResults);
    limpiarFiltros();
  } else {
    document.querySelector('.houses-section').scrollIntoView({ 
      behavior: 'smooth',
      block: 'start'
    });
  }
}

function limpiarFiltros() {
  document.getElementById('filterLocation').value = '';
  document.getElementById('filterType').value = '';
  document.getElementById('filterPrice').value = '';
  
  const properties = document.querySelectorAll('.property-card');
  properties.forEach(property => {
    property.classList.remove('hidden');
    property.classList.remove('highlight');
  });
}

function abrirVideoLightbox() {
  const lightbox = document.getElementById('videoLightbox');
  const videoFrame = document.getElementById('videoFrame');
  
  videoFrame.src = 'https://www.youtube.com/embed/fokXMm_-vDw?autoplay=1';
  lightbox.style.display = 'block';
  document.body.style.overflow = 'hidden';
}

function cerrarVideoLightbox() {
  const lightbox = document.getElementById('videoLightbox');
  const videoFrame = document.getElementById('videoFrame');
  
  videoFrame.src = '';
  lightbox.style.display = 'none';
  document.body.style.overflow = 'auto';
}

document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') {
    cerrarVideoLightbox();
  }
});

document.getElementById('videoLightbox')?.addEventListener('click', function(e) {
  if (e.target === this) {
    cerrarVideoLightbox();
  }
});