function handleLogin() {
  const form = document.querySelector("#login-form");

  if (!form) return;

  form.addEventListener("submit", (event) => {
    event.preventDefault(); // Evita que recargue la página automáticamente

    const formData = new FormData(form);
    const username = formData.get("username");
    const password = formData.get("password");

    if (username === "cenfo" && password === "123") {
      console.log("¡Login exitoso! Redireccionando...");
      window.location.href = `${window.location.origin}/landing.html`;
    } else {
      // Mostrar mensaje de error con SweetAlert2
      Swal.fire({
        icon: "error",
        title: "Error de acceso",
        text: "Combinación de usuario y contraseña incorrecta",
        confirmButtonText: "Intentar de nuevo",
        confirmButtonColor: "#1b3039",
      });
    }
  });
}

document.addEventListener("DOMContentLoaded", () => {
  handleLogin();
});

console.log("Hola desde login.js");
