const cantonesPorProvincia = {
  'San José': ['Central', 'Escazú', 'Desamparados', 'Puriscal', 'Tarrazú', 'Aserrí', 'Mora', 'Goicoechea', 'Santa Ana', 'Alajuelita', 'Vázquez de Coronado', 'Acosta', 'Tibás', 'Moravia', 'Montes de Oca', 'Turrubares', 'Dota', 'Curridabat', 'Pérez Zeledón', 'León Cortés'],
  'Alajuela': ['Central', 'San Ramón', 'Grecia', 'San Mateo', 'Atenas', 'Naranjo', 'Palmares', 'Poás', 'Orotina', 'San Carlos', 'Zarcero', 'Valverde Vega', 'Upala', 'Los Chiles', 'Guatuso', 'Río Cuarto'],
  'Cartago': ['Central', 'Paraíso', 'La Unión', 'Jiménez', 'Turrialba', 'Alvarado', 'Oreamuno', 'El Guarco'],
  'Heredia': ['Central', 'Barva', 'Santo Domingo', 'Santa Bárbara', 'San Rafael', 'San Isidro', 'Belén', 'Flores', 'San Pablo', 'Sarapiquí'],
  'Guanacaste': ['Liberia', 'Nicoya', 'Santa Cruz', 'Bagaces', 'Carrillo', 'Cañas', 'Abangares', 'Tilarán', 'Nandayure', 'La Cruz', 'Hojancha'],
  'Puntarenas': ['Central', 'Esparza', 'Buenos Aires', 'Montes de Oro', 'Osa', 'Quepos', 'Golfito', 'Coto Brus', 'Parrita', 'Corredores', 'Garabito', 'Monteverde'],
  'Limón': ['Central', 'Pococí', 'Siquirres', 'Talamanca', 'Matina', 'Guácimo']
};

function cargarCantones() {
  const provinciaSelect = document.getElementById('provincia');
  const cantonSelect = document.getElementById('canton');
  const provincia = provinciaSelect.value;
  
  cantonSelect.innerHTML = '<option value="">Selecciona un cantón</option>';
  
  if (provincia && cantonesPorProvincia[provincia]) {
    cantonSelect.disabled = false;
    
    cantonesPorProvincia[provincia].forEach(canton => {
      const option = document.createElement('option');
      option.value = canton;
      option.textContent = canton;
      cantonSelect.appendChild(option);
    });
  } else {
    cantonSelect.disabled = true;
    cantonSelect.innerHTML = '<option value="">Primero selecciona una provincia</option>';
  }
}

document.addEventListener('DOMContentLoaded', function() {
  const contactForm = document.getElementById('contactForm');
  
  if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
      e.preventDefault();
      
      const formData = new FormData(contactForm);
      
      if (!formData.get('provincia') || !formData.get('canton')) {
        alert('Por favor selecciona tu provincia y cantón.');
        return;
      }
      
      const submitBtn = contactForm.querySelector('.btn-submit');
      const originalText = submitBtn.textContent;
      submitBtn.disabled = true;
      submitBtn.textContent = 'Enviando...';
      
      emailjs.sendForm('service_ccu8yg7', 'template_076ksbl', '#contactForm', 'wIZvcoK8lJmVIhEsu')
      .then(function(response) {
        console.log('Formulario de contacto enviado!', response.status);
        
        contactForm.style.display = 'none';
        document.getElementById('contactThankYou').style.display = 'block';
        
        document.getElementById('contactThankYou').scrollIntoView({ 
          behavior: 'smooth',
          block: 'center'
        });
      })
      .catch(function(error) {
        console.error('Error al enviar formulario:', error);
        alert('Hubo un error al enviar el mensaje. Por favor intenta nuevamente.');
        submitBtn.disabled = false;
        submitBtn.textContent = originalText;
      });
    });
  }

  const subscriptionForm = document.getElementById('subscriptionForm');
  
  if (subscriptionForm) {
    subscriptionForm.addEventListener('submit', function(e) {
      e.preventDefault();
      
      const checkboxes = subscriptionForm.querySelectorAll('input[name="sub_interests"]:checked');
      
      if (checkboxes.length === 0) {
        alert('Por favor selecciona al menos un interés.');
        return;
      }
      
      const interests = Array.from(checkboxes).map(cb => cb.value).join(', ');
      
      const hiddenInput = document.createElement('input');
      hiddenInput.type = 'hidden';
      hiddenInput.name = 'interests_list';
      hiddenInput.value = interests;
      subscriptionForm.appendChild(hiddenInput);
      
      const submitBtn = subscriptionForm.querySelector('.btn-submit');
      const originalText = submitBtn.textContent;
      submitBtn.disabled = true;
      submitBtn.textContent = 'Enviando...';
      
      emailjs.sendForm('YOUR_SERVICE_ID', 'YOUR_TEMPLATE_ID_SUBSCRIPTION', '#subscriptionForm', 'YOUR_PUBLIC_KEY')
      .then(function(response) {
        console.log('Suscripción enviada!', response.status);
        
        subscriptionForm.style.display = 'none';
        document.getElementById('subscriptionThankYou').style.display = 'block';
        
        document.getElementById('subscriptionThankYou').scrollIntoView({ 
          behavior: 'smooth',
          block: 'center'
        });
      })
      .catch(function(error) {
        console.error('Error al enviar suscripción:', error);
        alert('Hubo un error al suscribirte. Por favor intenta nuevamente.');
        submitBtn.disabled = false;
        submitBtn.textContent = originalText;
        hiddenInput.remove();
      });
    });
  }
});

function resetContactForm() {
  const contactForm = document.getElementById('contactForm');
  const thankYou = document.getElementById('contactThankYou');
  
  contactForm.reset();
  document.getElementById('canton').disabled = true;
  document.getElementById('canton').innerHTML = '<option value="">Primero selecciona una provincia</option>';
  
  contactForm.style.display = 'block';
  thankYou.style.display = 'none';
  
  contactForm.scrollIntoView({ 
    behavior: 'smooth',
    block: 'start'
  });
}

function resetSubscriptionForm() {
  const subscriptionForm = document.getElementById('subscriptionForm');
  const thankYou = document.getElementById('subscriptionThankYou');
  
  subscriptionForm.reset();
  subscriptionForm.style.display = 'block';
  thankYou.style.display = 'none';
  
  subscriptionForm.scrollIntoView({ 
    behavior: 'smooth',
    block: 'start'
  });
}