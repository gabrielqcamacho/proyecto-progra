// ========== LIGHTBOX FOTOGRÁFICO ==========
let currentImageIndex = 0;
let galleryImages = [];

// Inicializar galería al cargar la página
document.addEventListener('DOMContentLoaded', function() {
  const galleryItems = document.querySelectorAll('.gallery-item');
  
  galleryItems.forEach((item, index) => {
    const img = item.querySelector('img');
    const title = item.querySelector('h5').textContent;
    const desc = item.querySelector('p').textContent;
    
    galleryImages.push({
      src: img.src,
      alt: img.alt,
      title: title,
      desc: desc
    });
    
    // Agregar evento click para abrir lightbox
    item.addEventListener('click', function() {
      abrirLightbox(index);
    });
  });
});

function abrirLightbox(index) {
  currentImageIndex = index;
  const modal = document.getElementById('lightboxModal');
  const img = document.getElementById('lightboxImg');
  const title = document.getElementById('lightboxTitle');
  const desc = document.getElementById('lightboxDesc');
  
  const imageData = galleryImages[index];
  
  img.src = imageData.src;
  img.alt = imageData.alt;
  title.textContent = imageData.title;
  desc.textContent = imageData.desc;
  
  modal.style.display = 'block';
  document.body.style.overflow = 'hidden'; // Evitar scroll
}

function cerrarLightbox() {
  const modal = document.getElementById('lightboxModal');
  modal.style.display = 'none';
  document.body.style.overflow = 'auto'; // Restaurar scroll
}

function cambiarImagen(direction) {
  currentImageIndex += direction;
  
  // Loop circular
  if (currentImageIndex >= galleryImages.length) {
    currentImageIndex = 0;
  } else if (currentImageIndex < 0) {
    currentImageIndex = galleryImages.length - 1;
  }
  
  const img = document.getElementById('lightboxImg');
  const title = document.getElementById('lightboxTitle');
  const desc = document.getElementById('lightboxDesc');
  
  const imageData = galleryImages[currentImageIndex];
  
  // Efecto de transición
  img.style.opacity = '0';
  setTimeout(() => {
    img.src = imageData.src;
    img.alt = imageData.alt;
    title.textContent = imageData.title;
    desc.textContent = imageData.desc;
    img.style.opacity = '1';
  }, 200);
}

// Cerrar lightbox con tecla ESC
document.addEventListener('keydown', function(e) {
  const modal = document.getElementById('lightboxModal');
  if (modal.style.display === 'block') {
    if (e.key === 'Escape') {
      cerrarLightbox();
    } else if (e.key === 'ArrowLeft') {
      cambiarImagen(-1);
    } else if (e.key === 'ArrowRight') {
      cambiarImagen(1);
    }
  }
});

// Cerrar lightbox al hacer click fuera de la imagen
document.getElementById('lightboxModal').addEventListener('click', function(e) {
  if (e.target === this) {
    cerrarLightbox();
  }
});

// ========== BUSCADOR FOTOGRÁFICO ==========
function buscarFotos() {
  const searchTerm = document.getElementById('photoSearch').value.toLowerCase().trim();
  
  if (searchTerm === '') {
    alert('Por favor ingrese un término de búsqueda');
    return;
  }
  
  const galleryItems = document.querySelectorAll('.gallery-item');
  let foundCount = 0;
  let firstFoundIndex = -1;
  
  galleryItems.forEach((item, index) => {
    const keywords = item.getAttribute('data-keywords').toLowerCase();
    const title = item.querySelector('h5').textContent.toLowerCase();
    const desc = item.querySelector('p').textContent.toLowerCase();
    
    // Buscar en keywords, título y descripción
    if (keywords.includes(searchTerm) || 
        title.includes(searchTerm) || 
        desc.includes(searchTerm)) {
      item.classList.remove('hidden');
      item.classList.add('highlight');
      foundCount++;
      
      if (firstFoundIndex === -1) {
        firstFoundIndex = index;
      }
      
      // Quitar highlight después de 1 segundo
      setTimeout(() => {
        item.classList.remove('highlight');
      }, 1000);
    } else {
      item.classList.add('hidden');
    }
  });
  
  if (foundCount === 0) {
    alert('No se encontraron imágenes con ese término. Intenta con: piscina, jardín, cocina, sala, etc.');
    limpiarBusqueda();
  } else {
    // Scroll suave hacia la galería
    document.querySelector('.main-gallery').scrollIntoView({ 
      behavior: 'smooth',
      block: 'start'
    });
    
    // Abrir la primera imagen encontrada en lightbox después de 1.5 segundos
    setTimeout(() => {
      if (firstFoundIndex !== -1) {
        abrirLightbox(firstFoundIndex);
      }
    }, 1500);
  }
}

function limpiarBusqueda() {
  document.getElementById('photoSearch').value = '';
  const galleryItems = document.querySelectorAll('.gallery-item');
  galleryItems.forEach(item => {
    item.classList.remove('hidden');
    item.classList.remove('highlight');
  });
}

// Buscar con Enter
document.getElementById('photoSearch').addEventListener('keypress', function(e) {
  if (e.key === 'Enter') {
    buscarFotos();
  }
});

// ========== FILTROS DE CATEGORÍA ==========
function filtrarCategoria(categoria) {
  const galleryItems = document.querySelectorAll('.gallery-item');
  const filterBtns = document.querySelectorAll('.filter-btn');
  
  // Actualizar botones activos
  filterBtns.forEach(btn => btn.classList.remove('active'));
  event.target.classList.add('active');
  
  // Filtrar imágenes
  galleryImages = []; // Limpiar array
  let newIndex = 0;
  
  galleryItems.forEach((item, index) => {
    const itemCategory = item.getAttribute('data-category');
    
    if (categoria === 'all' || itemCategory === categoria) {
      item.classList.remove('hidden');
      
      // Reconstruir array de imágenes visibles
      const img = item.querySelector('img');
      const title = item.querySelector('h5').textContent;
      const desc = item.querySelector('p').textContent;
      
      galleryImages.push({
        src: img.src,
        alt: img.alt,
        title: title,
        desc: desc
      });
      
      newIndex++;
    } else {
      item.classList.add('hidden');
    }
  });
}

// ========== TIRA FOTOGRÁFICA ==========
function scrollStrip(direction) {
  const strip = document.getElementById('photoStrip');
  const scrollAmount = 320; // Ancho del item + gap
  
  if (direction === 1) {
    strip.scrollLeft += scrollAmount;
  } else {
    strip.scrollLeft -= scrollAmount;
  }
}

// Auto-scroll de la tira fotográfica (opcional)
let autoScrollInterval;

function iniciarAutoScroll() {
  const strip = document.getElementById('photoStrip');
  
  autoScrollInterval = setInterval(() => {
    strip.scrollLeft += 1;
    
    // Si llegó al final, volver al inicio
    if (strip.scrollLeft >= strip.scrollWidth - strip.clientWidth) {
      strip.scrollLeft = 0;
    }
  }, 30);
}

function detenerAutoScroll() {
  clearInterval(autoScrollInterval);
}

// Activar/desactivar auto-scroll al pasar el mouse
document.addEventListener('DOMContentLoaded', function() {
  const strip = document.getElementById('photoStrip');
  
  strip.addEventListener('mouseenter', detenerAutoScroll);
  strip.addEventListener('mouseleave', iniciarAutoScroll);
  
  // Iniciar auto-scroll
  iniciarAutoScroll();
});